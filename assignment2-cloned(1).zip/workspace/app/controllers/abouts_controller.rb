class AboutsController < ApplicationController
  def display
  end
end
